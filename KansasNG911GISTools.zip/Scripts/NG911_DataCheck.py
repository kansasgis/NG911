#-------------------------------------------------------------------------------
# Name: NG911_DataCheck
# Purpose: Collection of functions to check submitted NG911 data
#
# Author: Kristen Jordan, Kansas Data Access and Support Center
# kristen@kgs.ku.edu
#
# Created: 19/09/2014
# Modified: 31/10/2014 by dirktall04
# Changes include: Adding the currentPathSettings variable from
# NG911_Config as the default variable passed to several Data
# Check functions, modifications to the functions to allow
# them to use that variable as a data source.
#Modified: 02/04/2014 by Kristen
#Changes include: modifying format so the checks work with the 1.1 template
#-------------------------------------------------------------------------------


from arcpy import (AddField_management, AddMessage, CalculateField_management,  CopyRows_management, CreateAddressLocator_geocoding,
                   CreateTable_management, Delete_management, Exists, GeocodeAddresses_geocoding, GetCount_management, FieldInfo,
                   ListFields, MakeFeatureLayer_management, MakeTableView_management, SelectLayerByAttribute_management, Statistics_analysis,
                   SelectLayerByLocation_management, RebuildAddressLocator_geocoding, DeleteRows_management, GetInstallInfo, env, ListDatasets)
from arcpy.da import Walk, InsertCursor, ListDomains, SearchCursor

from os import path
from os.path import basename, dirname, join

from time import strftime

from NG911_Config import getGDBObject

def getLayerList():
    layerList = ["RoadAlias", "AddressPoints", "RoadCenterline", "AuthoritativeBoundary", "CountyBoundary", "ESZ", "MunicipalBoundary"]
    return layerList


def getCurrentLayerList(esb):
    layerList = getLayerList()
    for e in esb:
        layerList.append(e)
    return layerList


def userMessage(msg):
    print msg
    AddMessage(msg)


def getCurrentDomainList(version):
    domainList = ["AddressNumbers", "AddressParity", "AgencyID", "Counties", "Country",
                    "ESBType", "Municipality", "OneWay", "PlaceType", "PointLocation", "PostalCodes",
                    "PostalCommunities", "RoadClass", "RoadDirectionals", "RoadModifier", "RoadStatus",
                    "RoadSurface", "RoadTypes", "States", "Stewards", "Exception", "Submit"]
    #or get domain list from approved source

    if version == "10":
        domainList.remove("Exception")
        domainList.remove("Submit")

    return domainList


def fieldsWithDomains(version, layer):
    #list of all the fields that have a domain
    if layer == "ADDRESSPOINTS":
        fieldList = ["STEWARD", "STATE", "COUNTY", "MUNI", "PRD", "STS", "POD", "POSTCO", "ZIP", "PLC", "LOCTYPE", "EXCEPTION", "SUBMIT"]
    elif layer == "ROADCENTERLINE":
        fieldList = ["STEWARD", "STATE_L", "STATE_R", "COUNTY_L", "COUNTY_R", "MUNI_L", "MUNI_R", "PARITY_L", "PARITY_R", "POSTCO_L", "POSTCO_R", "ZIP_L", "ZIP_R", "PRD", "STS", "POD", "ONEWAY", "RDCLASS", "SURFACE", "STATUS", "EXCEPTION", "SUBMIT"]
    elif layer == "ESB":
        fieldList = ["STEWARD", "STATE", "AGENCYID", "SUBMIT"]
    elif layer == "AUTHORITATIVEBOUNDARY":
        fieldList = ["STEWARD", "AGENCYID", "SUBMIT"]
    elif layer == "ROADALIAS":
        fieldList = ["STEWARD", "A_PRD", "A_STS", "A_POD", "SUBMIT"]
    elif layer == "COUNTYBOUNDARY":
        fieldList = ["STEWARD", "STATE", "COUNTY"]
    elif layer == "MUNICIPALBOUNDARY":
        fieldList = ["STEWARD", "STATE", "COUNTY", "MUNI", "SUBMIT"]
    elif layer == "ESZ":
        fieldList = ["STEWARD", "AGENCYID", "SUBMIT"]
    elif layer == "PSAP":
        fieldList = ["STEWARD", "STATE", "AGENCYID", "SUBMIT"]

    #take out fields if it's a different version of geodatabase
    if version == "10":
        removeList = ["EXCEPTION", "SUBMIT"]
        for rL in removeList:
            if rL in fieldList:
                fieldList.remove(rL)

    return fieldList

def getUniqueIDField(layer):
    id_dict = {"ADDRESSPOINTS":"ADDID", "AUTHORITATIVEBOUNDARY":"ABID", "COUNTYBOUNDARY":"CountyID", "ESB":"ESBID", "ESZ":"ESZID", "MUNICIPALBOUNDARY":"MUNI_ID", "PSAP":"ESBID", "ROADCENTERLINE":"SEGID", "ROADALIAS":"ALIASID"}
    try:
        id1 = id_dict[layer]
    except:
        id1 = ""
    return id1

def getDomainKeyword(domainName):
    ucase_list = ["AgencyID", "Country", "OneWay"]
    if domainName == "AddressParity":
        keyword = "PARITY"
    elif domainName == "Counties":
        keyword = "COUNTY"
    elif domainName == "ESBType":
        keyword = ""
    elif domainName == "Municipality":
        keyword = "MUNI"
    elif domainName == "PlaceType":
        keyword = "PLC"
    elif domainName == "PointLocation":
        keyword = "LOCTYPE"
    elif domainName == "PostalCodes":
        keyword = "ZIP"
    elif domainName == "PostalCommunities":
        keyword = "POSTCO"
    elif domainName == "RoadClass":
        keyword = "RDClass"
    elif domainName == "RoadDirectionals":
        keyword = "PRD"
    elif domainName == "RoadModifier":
        keyword = ""
    elif domainName == "RoadStatus":
        keyword = "STATUS"
    elif domainName == "RoadSurface":
        keyword = "SURFACE"
    elif domainName == "RoadTypes":
        keyword = "STS"
    elif domainName == "States":
        keyword = "STATE"
    elif domainName == "Stewards":
        keyword = "STEWARD"
    elif domainName in ucase_list:
        keyword = domainName.upper()

    return keyword


def getAddFieldInfo(table):
    lyr = basename(table)
    #field info
    if lyr == "TemplateCheckResults":
        fieldInfo = [(table, "DateFlagged", "DATE", "", "", ""),(table, "Description", "TEXT", "", "", 250),(table, "Category", "TEXT", "", "", 25)]
    elif lyr == "FieldValuesCheckResults":
        fieldInfo = [(table, "DateFlagged", "DATE", "", "", ""),(table, "Description", "TEXT", "", "", 250),(table, "Layer", "TEXT", "", "", 25),(table, "Field", "TEXT", "", "", 25),(table, "FeatureID", "TEXT", "", "", 38)]
    elif lyr == "DASC_Communication":
        fieldInfo = [(table, "NoteDate", "DATE", "", "", ""),(table, "Description", "TEXT", "", "", 250)]

    return fieldInfo


def getResultsFieldList(table):
    #get field info
    fieldInfo = getAddFieldInfo(table)
    fieldList = []
    #loop through added fields
    for fi in fieldInfo:
        #append the field name
        fieldList.append(fi[1])

    return fieldList


def RecordResults(resultType, values, gdb): # Guessed on whitespace formatting here. -- DT
    if resultType == "template":
        tbl = "TemplateCheckResults"
    elif resultType == "fieldValues":
        tbl = "FieldValuesCheckResults"
    elif resultType == "DASCmessage":
        tbl = "DASC_Communication"

    table = join(gdb, tbl)
    fieldList = []

    if not Exists(table):
        CreateTable_management(gdb, tbl)
        fieldInfo = getAddFieldInfo(table)

        for fi in fieldInfo:
            #add field with desired parameters
            AddField_management(fi[0],fi[1],fi[2],fi[3],fi[4],fi[5])
            #populate field list
            fieldList.append(fi[1])

    if fieldList == []:
        fieldList = getResultsFieldList(table)

    cursor = InsertCursor(table, fieldList)
    for row in values:
        try:
            cursor.insertRow(row)
        except:
            userMessage(row)
    del cursor

def geocodeAddressPoints(pathsInfoObject):
    gdb = pathsInfoObject.gdbPath

    version = pathsInfoObject.gdbVersion

    env.workspace = gdb
    addressPointPath = "AddressPoints"
    streetPath = "RoadCenterline"
    roadAliasPath = "RoadAlias"

    userMessage("Geocoding address points...")

    gc_table = "GeocodeTable"
    sl_field = "SingleLineInput"
    Locator = "Locator"
    addyview = "addy_view"
    output = "gc_test"

    # Get the fields from the input
    fields = ListFields(addressPointPath)

    # Create a fieldinfo object
    fieldinfo = FieldInfo()

    # Iterate through the fields and set them to fieldinfo
    for field in fields:
        if field.name in ("LABEL", "ZIP"):
            fieldinfo.addField(field.name, field.name, "VISIBLE", "")
    else:
        fieldinfo.addField(field.name, field.name, "HIDDEN", "")

    userMessage("Preparing addresses...")
    # The created addyview layer will have fields as set in fieldinfo object
    if version == "10":
        MakeTableView_management(addressPointPath, addyview, "", "", fieldinfo)
    else:
        wc = "SUBMIT = 'Y'"
        MakeTableView_management(addressPointPath, addyview, wc, "", fieldinfo)

    # To persist the layer on disk make a copy of the view
    if Exists(gc_table):
        try:
            Delete_management(gc_table)
        except:
            userMessage("Please manually delete the table called gc_table and then run the geocoding again")

    if not Exists(gc_table):
        CopyRows_management(addyview, gc_table)

        #add single line input field for geocoding
        AddField_management(gc_table, sl_field, "TEXT", "", "", 250)

        #calculate field
        exp = '[LABEL] & " " & [ZIP]'
        CalculateField_management(gc_table, sl_field, exp, "VB")

        #generate locator
        fieldMap = """'Primary Table:Feature ID' <None> VISIBLE NONE;'*Primary Table:From Left' RoadCenterline:L_F_ADD VISIBLE NONE;
        '*Primary Table:To Left' RoadCenterline:L_T_ADD VISIBLE NONE;'*Primary Table:From Right' RoadCenterline:R_F_ADD VISIBLE NONE;
        '*Primary Table:To Right' RoadCenterline:R_T_ADD VISIBLE NONE;'Primary Table:Prefix Direction' RoadCenterline:PRD VISIBLE NONE;
        'Primary Table:Prefix Type' RoadCenterline:STP VISIBLE NONE;'*Primary Table:Street Name' RoadCenterline:RD VISIBLE NONE;
        'Primary Table:Suffix Type' RoadCenterline:STS VISIBLE NONE;'Primary Table:Suffix Direction' RoadCenterline:POD VISIBLE NONE;
        'Primary Table:Left City or Place' RoadCenterline:MUNI_L VISIBLE NONE;
        'Primary Table:Right City or Place' RoadCenterline:MUNI_R VISIBLE NONE;
        'Primary Table:Left ZIP Code' RoadCenterline:ZIP_L VISIBLE NONE;'Primary Table:Right ZIP Code' RoadCenterline:ZIP_R VISIBLE NONE;
        'Primary Table:Left State' RoadCenterline:STATE_L VISIBLE NONE;'Primary Table:Right State' RoadCenterline:STATE_R VISIBLE NONE;
        'Primary Table:Left Street ID' <None> VISIBLE NONE;'Primary Table:Right Street ID' <None> VISIBLE NONE;
        'Primary Table:Min X value for extent' <None> VISIBLE NONE;'Primary Table:Max X value for extent' <None> VISIBLE NONE;
        'Primary Table:Min Y value for extent' <None> VISIBLE NONE;'Primary Table:Max Y value for extent' <None> VISIBLE NONE;
        'Primary Table:Left Additional Field' <None> VISIBLE NONE;'Primary Table:Right Additional Field' <None> VISIBLE NONE;
        'Primary Table:Altname JoinID' RoadCenterline:SEGID VISIBLE NONE;'*Alternate Name Table:JoinID' RoadAlias:SEGID VISIBLE NONE;
        'Alternate Name Table:Prefix Direction' RoadAlias:A_PRD VISIBLE NONE;'Alternate Name Table:Prefix Type' <None> VISIBLE NONE;
        'Alternate Name Table:Street Name' RoadAlias:A_RD VISIBLE NONE;'Alternate Name Table:Suffix Type' RoadAlias:A_STS VISIBLE NONE;
        'Alternate Name Table:Suffix Direction' RoadAlias:A_POD VISIBLE NONE"""

        userMessage("Creating address locator...")
        # Process: Create Address Locator
        if Exists(Locator):
            RebuildAddressLocator_geocoding(Locator)
        else:
            try:
                CreateAddressLocator_geocoding("US Address - Dual Ranges", streetPath + " 'Primary Table';" + roadAliasPath + " 'Alternate Name Table'", fieldMap, Locator, "")
            except:
                try:
                    fieldMap = """'Primary Table:Feature ID' <None> VISIBLE NONE;'*Primary Table:From Left' RoadCenterline:L_F_ADD VISIBLE NONE;
                    '*Primary Table:To Left' RoadCenterline:L_T_ADD VISIBLE NONE;'*Primary Table:From Right' RoadCenterline:R_F_ADD VISIBLE NONE;
                    '*Primary Table:To Right' RoadCenterline:R_T_ADD VISIBLE NONE;'Primary Table:Prefix Direction' RoadCenterline:PRD VISIBLE NONE;
                    'Primary Table:Prefix Type' RoadCenterline:STP VISIBLE NONE;'*Primary Table:Street Name' RoadCenterline:RD VISIBLE NONE;
                    'Primary Table:Suffix Type' RoadCenterline:STS VISIBLE NONE;'Primary Table:Suffix Direction' RoadCenterline:POD VISIBLE NONE;
                    'Primary Table:Left City or Place' RoadCenterline:MUNI_L VISIBLE NONE;
                    'Primary Table:Right City or Place' RoadCenterline:MUNI_R VISIBLE NONE;
                    'Primary Table:Left ZIP Code' RoadCenterline:ZIP_L VISIBLE NONE;'Primary Table:Right ZIP Code' RoadCenterline:ZIP_R VISIBLE NONE;
                    'Primary Table:Left State' RoadCenterline:STATE_L VISIBLE NONE;'Primary Table:Right State' RoadCenterline:STATE_R VISIBLE NONE;
                    'Primary Table:Left Street ID' <None> VISIBLE NONE;'Primary Table:Right Street ID' <None> VISIBLE NONE;
                    'Primary Table:Display X' <None> VISIBLE NONE;'Primary Table:Display Y' <None> VISIBLE NONE;
                    'Primary Table:Min X value for extent' <None> VISIBLE NONE;'Primary Table:Max X value for extent' <None> VISIBLE NONE;
                    'Primary Table:Min Y value for extent' <None> VISIBLE NONE;'Primary Table:Max Y value for extent' <None> VISIBLE NONE;
                    'Primary Table:Left Additional Field' <None> VISIBLE NONE;'Primary Table:Right Additional Field' <None> VISIBLE NONE;
                    'Primary Table:Altname JoinID' RoadCenterline:SEGID VISIBLE NONE;'*Alternate Name Table:JoinID' RoadAlias:SEGID VISIBLE NONE;
                    'Alternate Name Table:Prefix Direction' RoadAlias:A_PRD VISIBLE NONE;'Alternate Name Table:Prefix Type' <None> VISIBLE NONE;
                    'Alternate Name Table:Street Name' RoadAlias:A_RD VISIBLE NONE;'Alternate Name Table:Suffix Type' RoadAlias:A_STS VISIBLE NONE;
                    'Alternate Name Table:Suffix Direction' RoadAlias:A_POD VISIBLE NONE"""
                    CreateAddressLocator_geocoding("US Address - Dual Ranges", streetPath + " 'Primary Table';" + roadAliasPath + " 'Alternate Name Table'", fieldMap, Locator, "", "DISABLED")
                except Exception as E:
                    userMessage(Locator)
                    userMessage("Cannot create address locator. Please email kristen@kgs.ku.edu this error message: " + str(E))


        if Exists(Locator):
            userMessage("Geocoding addresses...")

            #geocode table address
            if Exists(output):
                Delete_management(output)

            #define geocoding exception table
            ge = join(gdb, "GeocodeExceptions")

            i = 0

            #set up geocoding
            gc_fieldMap = "Street LABEL VISIBLE NONE;City MUNI VISIBLE NONE;State State VISIBLE NONE;ZIP ZIP VISIBLE NONE"

            #geocode addresses
            try:
                GeocodeAddresses_geocoding(gc_table, Locator, gc_fieldMap, output, "STATIC")
                i = 1
            except:
                gc_fieldMap = "Street LABEL VISIBLE NONE;City MUNI VISIBLE NONE;State State VISIBLE NONE"

                try:
                    GeocodeAddresses_geocoding(gc_table, Locator, gc_fieldMap, output, "STATIC")
                    i = 1
                except:
                    userMessage("Could not geocode address points")

            #report records that didn't geocode
            if i == 1:
                wc = "Status <> 'M'"
                lyr = "lyr"

                MakeFeatureLayer_management(output, lyr, wc)

                rStatus = GetCount_management(lyr)
                rCount = int(rStatus.getOutput(0))

                if rCount > 0:
                    #set up parameters to report records that didn't geocode
                    values = []
                    recordType = "fieldValues"
                    today = strftime("%m/%d/%y")
                    filename = "AddressPoints"

                    rfields = ("ADDID")
                    with SearchCursor(output, rfields, wc) as rRows:
                        for rRow in rRows:
                            fID = rRow[0]

                            #see if the fID exists as an exception
                            if Exists(ge):
                                wcGE = "ADDID = '" + fID + "'"
                                tblGE = "tblGE"
                                MakeTableView_management(ge, tblGE, wcGE)

                                geStatus = GetCount_management(tblGE)
                                geCount = int(geStatus.getOutput(0))

                                if geCount != 0:
                                    userMessage(fID + " has already been marked as a geocoding exception")
                                    rCount = rCount - 1
                                else:
                                    #report as an error
                                    report = str(fID) + " did not geocode against centerline"
                                    val = (today, report, filename, "", fID)
                                    values.append(val)
                                Delete_management(tblGE)

                            else:
                                report = str(fID) + " did not geocode against centerline"
                                val = (today, report, filename, "", fID)
                                values.append(val)

                    if rCount > 0:
                        userMessage("Completed geocoding with " + str(rCount) + " errors.")
                        #report records
                        if values != []:
                            RecordResults(recordType, values, gdb)
                    else:
                        userMessage("Some records did not geocode, but they are marked as exceptions.")

                else:
                    #this means all the records geocoded
                    userMessage("All records geocoded successfully.")
                    try:
                        Delete_management(output)
                    except:
                        userMessage("Geocoding table could not be deleted")
        else:
            userMessage("Could not geocode addresses")

def checkESNandMuniAttribute(currentPathSettings):

    NG911gdb = currentPathSettings.gdbPath
    esz = currentPathSettings.ESZ

    gdb_object = getGDBObject(NG911gdb)

    address_points = gdb_object.AddressPoints
    muni = gdb_object.MunicipalBoundary

    addy_lyr = "addy_lyr"
    MakeFeatureLayer_management(address_points, addy_lyr)

    values = []
    recordType = "fieldValues"
    today = strftime("%m/%d/%y")
    filename = "AddressPoints"

    searchDict = {esz: ("ESN", "OBJECTID"), muni: ("MUNI", "OBJECTID")}

    for layer, fieldList in searchDict.iteritems():

        with SearchCursor(layer, fieldList) as polys:
            for poly in polys:
                feature = fieldList[0]
                feature_value = poly[0]

                #make feature layer
                lyr1 = "lyr1"
                qry = "OBJECTID = " + str(poly[1])
                MakeFeatureLayer_management(layer, lyr1, qry)

                #select by location
                SelectLayerByLocation_management(addy_lyr, "INTERSECT", lyr1)

                #loop through address points
                with SearchCursor(addy_lyr, (feature, "ADDID")) as rows:
                    for row in rows:
                        #get value
                        value_addy = row[0]

                        #see if the values match
                        if value_addy != feature_value:
                            segID = row[1]

                            report = "Address point " + feature + " does not match " + feature + " in " + basename(layer) + " layer"
                            val = (today, report, filename, feature, segID)
                            values.append(val)


                Delete_management(lyr1)
                del lyr1

        del poly, polys

    #report records
    if values != []:
        RecordResults(recordType, values, NG911gdb)
        userMessage("Address point ESN/Municipality check complete. " + str(len(values)) + " issues found. Results are in the FieldValuesCheckResults table.")
    else:
        userMessage("Address point ESN/Municipality check complete. No issues found.")

def checkUniqueIDFrequency(currentPathSettings):
    gdb = currentPathSettings.gdbPath
    esbList = currentPathSettings.esbList
    fcList = currentPathSettings.fcList

    layerList = []

    env.workspace = gdb
    table = "ESB_IDS"

    #create temp table of esbID's
    if esbList <> [] and esbList[0] != esbList[1]:
        layerList = ["ESB_IDS"]

        if Exists(table):
            Delete_management(table)

        CreateTable_management(gdb, table)

        AddField_management(table, "ESBID", "TEXT", "", "", 38)
        AddField_management(table, "ESB_LYR", "TEXT", "", "", 30)

        esbFields = ("ESBID")

        #copy ID's & esb layer type into the table
        for esb in esbList:
            with SearchCursor(esb, esbFields) as rows:
                for row in rows:
                    cursor = InsertCursor(table, ('ESBID', 'ESB_LYR'))
                    cursor.insertRow((row[0], esb))

        try:
            #clean up
            del rows, row, cursor
        except:
            print "objects cannot be deleted, they don't exist"

    else:
        for fc in fcList:
            fc = basename(fc)
            layerList.append(fc)

    #loop through layers in the gdb that aren't esb & ESB_IDS
##    layers = getCurrentLayerList(esb)
##    layers.append("ESB_IDS")

    values = []
    recordType = "fieldValues"
    today = strftime("%m/%d/%y")

    for layer in layerList:
##        if layer not in esb:
        if layer != "ESB_IDS":
            #for each layer, get the unique ID field
            uniqueID = getUniqueIDField(layer.upper())

        else:
            #for esb layers, get the unique ID field
            uniqueID = "ESBID"

        freq_table = layer + "_freq"

        if Exists(freq_table):
            Delete_management(freq_table)

        Statistics_analysis(layer, freq_table, [[uniqueID,"COUNT"]], uniqueID)

        #set parameters for the search cursor
        where_clause = "FREQUENCY > 1"
        fields = (uniqueID, "FREQUENCY")

        fl = "fl"

        MakeTableView_management(freq_table, fl, where_clause)

        result = GetCount_management(fl)
        count = int(result.getOutput(0))

        if count > 0:

            #set a search cursor with just the unique ID field
            with SearchCursor(freq_table, fields, where_clause) as rows2:
                stringESBReport = ""
                for row2 in rows2:
                    if layer == "ESB_IDS":
                        stringEsbInfo = []
                        wc2 = "ESBID = '" + str(row2[0]) + "'"
                        with SearchCursor("ESB_IDS", ("ESB_LYR"), wc2) as esbRows:
                            for esbRow in esbRows:
                                stringEsbInfo.append(esbRow[0])

                        stringESBReport = " and ".join(stringEsbInfo)

                    #report duplicate IDs
                    report = str(row2[0]) + " is a duplicate ID"
                    if stringESBReport != "":
                        report = report + " in " + stringESBReport
                    val = (today, report, "ESB", uniqueID, row2[0])
                    values.append(val)

        Delete_management(freq_table)
        Delete_management(fl)

    #report duplicate records
    if values != []:
        RecordResults(recordType, values, gdb)
        userMessage("Checked unique ID frequency. Results are in table FieldValuesCheckResults.")
    else:
        userMessage("All ID's are unique.")

    #if it exists, clean up table
    if Exists(table):
        Delete_management(table)

def checkFrequency(fc, freq, fields, gdb, version):
    fl = "fl"
    fl1 = "fl1"
    wc = "FREQUENCY > 1"

    #remove the frequency table if it exists already
    if Exists(freq):
        try:
            Delete_management(freq)
        except:
            userMessage("Please manually delete " + freq + " and then run the frequency check again")

    if not Exists(freq):
        try:
            #see if we're working with address points or roads, create a where clause
            filename = ""
            if freq == join(gdb, "AP_Freq"):
                filename = "AddressPoints"
                wc1 = "HNO <> 0 and LOC = 'PRIMARY'"
            elif freq == join(gdb, "Road_Freq"):
                filename = "RoadCenterline"
                wc1 = "L_F_ADD <> 0 AND L_T_ADD <> 0 AND R_F_ADD <> 0 AND R_T_ADD <> 0"

            if version != "10":
                wc1 = wc1 + " AND SUBMIT = 'Y'"

            #run query on fc to make sure 0's are ignored
            MakeTableView_management(fc, fl1, wc1)

            #split field names
            fieldsList = fields.split(";")
            fieldCountList = []
            fl_fields = []
            for f in fieldsList:
                f = f.strip()
                fList = [f,"COUNT"]
                fieldCountList.append(fList)
                fl_fields.append(f)

            #run frequency analysis
            Statistics_analysis(fl1, freq, fieldCountList, fields)

            #make feature layer
            MakeTableView_management(freq, fl, wc)

            #get count of the results
            result = GetCount_management(fl)
            count = int(result.getOutput(0))

            if count > 0:

                #set up parameters to report duplicate records
                values = []
                recordType = "fieldValues"
                today = strftime("%m/%d/%y")

                #add information to FieldValuesCheckResults for all duplicates

                #get field count
                fCount = len(fl_fields)

                #get the unique ID field name
                id1 = getUniqueIDField(filename.upper())

                #run a search on the frequency table to report duplicate records
                with SearchCursor(freq, fl_fields, wc) as rows:
                    for row in rows:
                        i = 0
                        #generate where clause to find duplicate ID's
                        wc = ""
                        while i < fCount:
                            stuff = ""
                            if row[i] != None:
                                try:
                                    stuff = " = '" + row[i] + "' "
                                except:
                                    stuff = " = " + str(row[i]) + " "
                            else:
                                stuff = " is null "
                            wc = wc + fl_fields[i] + stuff + "and "
                            i += 1

                        #trim last "and " off where clause
                        wc = wc[0:-5]

                        #find records with duplicates to get their unique ID's
                        with SearchCursor(fl1, (id1), wc) as sRows:
                            for sRow in sRows:
                                fID = sRow[0]
                                report = str(fID) + " has duplicate field information"
                                val = (today, report, filename, "", fID)
                                values.append(val)

                #report duplicate records
                if values != []:
                    RecordResults(recordType, values, gdb)
                    userMessage("Checked frequency. Results are in table FieldValuesCheckResults")

            elif count == 0:
                userMessage("Checked frequency. All records are unique.")

            #clean up
            Delete_management(fl)
            Delete_management(fl1)

            try:
                Delete_management(freq)
            except:
                userMessage("Could not delete frequency table")
        except:
            userMessage("Could not fully run frequency check")

def checkLayerList(pathsInfoObject):
    gdb = pathsInfoObject.gdbPath
    esb = pathsInfoObject.esbList

    values = []
    today = strftime("%m/%d/%y")

    #make sure the NG911 feature dataset exists
    userMessage("Checking feature dataset name...")
    env.workspace = gdb

    datasets = ListDatasets()

    if "NG911" not in datasets:
        dataset_report = "No feature dataset named 'NG911' exists"
        val = (today, dataset_report, "Template")
        values.append(val)
        userMessage(dataset_report)

    userMessage("Checking geodatabase layers...")
    #get current layer list
    layerList = getCurrentLayerList(esb)
    layers = []
    for dirpath, dirnames, filenames in Walk(gdb, True, '', False, ["Table","FeatureClass"]):
##        ignoreList = ("gc_test", "TemplateCheckResults", "FieldValuesCheckResults", "GeocodeTable")
        for fn in filenames:
            name = basename(fn)
            layers.append(name)

##    userMessage(layers)

    #report any required layers that are not present
    for l in layerList:
        if l not in layers:
            report = "Required layer " + l + " is not in geodatabase."
            userMessage(report)
            val = (today, report, "Layer")
            values.append(val)

    #record issues if any exist
    if values != []:
        RecordResults("template", values, gdb)


def getKeyword(layer, esb):
    if layer in esb:
        keyword = "EmergencyBoundary"
    else:
        keyword = layer

    return keyword


def getRequiredFields(folder, version):
    path1 = path.join(folder, "NG911_RequiredFields.txt")

    #create a field definition dictionary
    rfDict = {}

    #make sure file path exists
    if path.exists(path1):
        fieldDefDoc = open(path1, "r")

        #get the header information
        headerLine = fieldDefDoc.readline()
        valueList = headerLine.split("|")
        ## print valueList

        #get field indexes
        fcIndex = valueList.index("FeatureClass")
        fieldIndex = valueList.index("Field\n")

        #parse the text to populate the field definition dictionary
        for line in fieldDefDoc.readlines():
            stuffList = line.split("|")
            #set up values
            fc = stuffList[0]
            field = stuffList[1].rstrip()
            fieldList = []

            #see if field list already exists
            if fc in rfDict.iterkeys():
                fieldList = rfDict[fc]

            #append new value onto list
            fieldList.append(field)

            if version == "10":
                if "EXCEPTION" in fieldList:
                    fieldList.remove("EXCEPTION")
            #set value as list
            rfDict[fc] = fieldList
    else:
        userMessage("The file " + path1 + " is required to run field checks.")

    return rfDict


def getFieldDomain(field, folder):
##    userMessage(field)
    if "_" in field:
        f = field.split("_")
        field = f[0]

    docPath = path.join(folder, field + "_Domains.txt")
    ## print docPath

    domainDict = {}

    #make sure path exists
    if path.exists(docPath):
        doc = open(docPath, "r")

        headerLine = doc.readline()
        valueList = headerLine.split("|")

        valueIndex = valueList.index("Values")
        defIndex = valueList.index("Definition\n")


        #parse the text to population the field definition dictionary
        for line in doc.readlines():
            if line != "\n":
                stuffList = line.split("|")
    ##            userMessage(stuffList)
                domainDict[stuffList[0].rstrip().lstrip()] = stuffList[1].rstrip().lstrip()

    else:
        userMessage("The file " + docPath + " is required to run a domain check.")

    return domainDict


def checkValuesAgainstDomain(pathsInfoObject):
    gdb = pathsInfoObject.gdbPath
    folder = pathsInfoObject.domainsFolderPath
    fcList = pathsInfoObject.fcList
    esb = pathsInfoObject.esbList
    version = pathsInfoObject.gdbVersion

    userMessage("Checking field values against approved domains...")
    #set up parameters to report duplicate records
    values = []
    resultType = "fieldValues"
    today = strftime("%m/%d/%y")
    filename = ""

    #set environment
    env.workspace = gdb

    for fullPath in fcList:
        fc = basename(fullPath).replace("'", "")
        layer = fc.upper()
        if fc in esb:
            layer = "ESB"

        #get list of fields with domains
        fieldsWDoms = fieldsWithDomains(version, layer)

##        #remove "STATUS" field if we aren't working with road centerline- edit suggested by Sherry M., 6/16/2015
##        if layer != "ROADCENTERLINE":
##            if "STATUS" in fieldsWDoms:
##                fieldsWDoms.remove("STATUS")

        id1 = getUniqueIDField(layer)
        if id1 != "":
            fields = []
            #create complete field list
            fields = ListFields(fc)
            fieldNames = []

            for f in fields:
                fieldNames.append(f.name)

            #see if fields from complete list have domains
            for fieldN in fieldNames:

                #userMessage(fieldN)
                #if field has a domain
                if fieldN in fieldsWDoms:
                    domain = ""
                    if fieldN[0:2] == "A_":
                        domain = fieldN[2:]
                    else:
                        domain = fieldN

                    userMessage("Checking: " + fieldN)
                    #get the full domain dictionary
                    domainDict = getFieldDomain(domain, folder)

                    if domainDict != {}:
                        #put domain values in a list
                        domainList = []

                        for val in domainDict.iterkeys():
                            domainList.append(val)

                        #add values for some CAD users of blank and space (edit suggested by Sherry M. & Keith S. Dec 2014)
                        domainList.append('')
                        domainList.append(" ")

                        #if the domain is counties, add county names to the list without "COUNTY" so both will work (edit suggest by Keith S. Dec 2014)
                        if fieldN == "COUNTY":
                            q = len(domainList)
                            i = 0
                            while i < q:
                                dl1 = domainList[i].split(" ")[0]
    ##                            userMessage(dl1)
                                domainList.append(dl1)
                                i += 1

                        #loop through records for that particular field to see if all values match domain
                        wc = fieldN + " is not null"
                        with SearchCursor(fullPath, (id1, fieldN), wc) as rows:
                            for row in rows:
                                if row[1] is not None:
                                    fID = row[0]
                                    #see if field domain is actually a range
                                    if fieldN == "HNO":
                                        hno = row[1]
                                        if hno > 999999 or hno < 0:
                                            report = "Value " + str(row[1]) + " not in approved domain for field " + fieldN
                                            val = (today, report, fc, fieldN, fID)
                                            values.append(val)
                                    #otherwise, compare row value to domain list
                                    else:
##                                        userMessage("Checking value: " + row[1])
                                        if row[1] not in domainList:
                                            report = "Value " + str(row[1]) + " not in approved domain for field " + fieldN
                                            val = (today, report, fc, fieldN, fID)
                                            values.append(val)

                    else:
                        userMessage("Could not compare domain for " + fieldN)
        userMessage("Checked " + layer)

    if values != []:
        RecordResults(resultType, values, gdb)

    userMessage("Completed checking fields against domains: " + str(len(values)) + " issues found")


def checkRequiredFieldValues(pathsInfoObject):
    gdb = pathsInfoObject.gdbPath
    folder = pathsInfoObject.domainsFolderPath
    esb = pathsInfoObject.esbList
    version = pathsInfoObject.gdbVersion

    userMessage("Checking that required fields have all values...")

    #get today's date
    today = strftime("%m/%d/%y")

    #get required fields
    rfDict = getRequiredFields(folder, version)

    if rfDict != {}:

        values = []

        #walk through the tables/feature classes
        for dirpath, dirnames, filenames in Walk(gdb, True, '', False, ["Table","FeatureClass"]):
            for filename in filenames:
                if filename.upper() not in ("FIELDVALUESCHECKRESULTS", "TEMPLATECHECKRESULTS"):
                    fullPath = path.join(gdb, filename)
                    if filename.upper() in esb:
                        layer = "ESB"
                    else:
                        layer = filename.upper()
                    id1 = getUniqueIDField(layer)
                    if id1 != "":

                        #get the keyword to acquire required field names
                        keyword = getKeyword(filename, esb)

                        #goal: get list of required fields that are present in the feature class
                        #get the appropriate required field list
                        if keyword in rfDict:
                            requiredFieldList = rfDict[keyword]

                        rfl = []
                        for rf in requiredFieldList:
                            rfl.append(rf.upper())

                        #get list of fields in the feature class
                        allFields = ListFields(fullPath)

                        #make list of field names
                        fields = []
                        for aF in allFields:
                            fields.append(aF.name.upper())

                        #convert lists to sets
                        set1 = set(rfl)
                        set2 = set(fields)

                        #get the set of fields that are the same
                        matchingFields = list(set1 & set2)

                        #only work with records that are for submission
                        lyr2 = "lyr2"
                        if version == "10":
                            MakeTableView_management(fullPath, lyr2)
                        else:
                            wc2 = "SUBMIT = 'Y'"
                            MakeTableView_management(fullPath, lyr2, wc2)

                        #get count of the results
                        result2 = GetCount_management(lyr2)
                        count2 = int(result2.getOutput(0))

                        if count2 > 0:

                            #create where clause to select any records where required values aren't populated
                            wc = ""

                            for field in matchingFields:
                                wc = wc + " " + field + " is null or "

                            wc = wc[0:-4]

                            #make table view using where clause
                            lyr = "lyr"
                            MakeTableView_management(lyr2, lyr, wc)

                            #get count of the results
                            result = GetCount_management(lyr)
                            count = int(result.getOutput(0))


                            #if count is greater than 0, it means a required value somewhere isn't filled in
                            if count > 0:
                                #make sure the objectID gets included in the search for reporting
                                if id1 not in matchingFields:
                                    matchingFields.append(id1)

                                #run a search cursor to get any/all records where a required field value is null
                                with SearchCursor(lyr, (matchingFields), wc) as rows:
                                    for row in rows:
                                        k = 0
                                        #get object ID of the field
                                        oid = str(row[matchingFields.index(id1)])

                                        #loop through row
                                        while k < len(matchingFields):
                                            #see if the value is nothing
                                            if row[k] is None:
                                                #report the value if it is indeed null
                                                report = matchingFields[k] + " is null for Feature ID " + oid
                                                userMessage(report)
                                                val = (today, report, filename, matchingFields[k], oid)
                                                values.append(val)

                                            #iterate!
                                            k = k + 1
                            else:
                                userMessage( "All required values present for " + filename)

                            Delete_management(lyr)

                        else:
                            userMessage(filename + " has no records marked for submission. Data will not be verified.")
                        Delete_management(lyr2)

        if values != []:
            RecordResults("fieldValues", values, gdb)

        userMessage("Completed check for required field values: " + str(len(values)) + " issues found")

    else:
        userMessage("Could not check required field values")


def checkRequiredFields(pathsInfoObject):
    gdb = pathsInfoObject.gdbPath
    folder = pathsInfoObject.domainsFolderPath
    esb = pathsInfoObject.esbList
    version = pathsInfoObject.gdbVersion

    userMessage("Checking that required fields exist...")

    #get today's date
    today = strftime("%m/%d/%y")
    values = []

    #get required fields
    rfDict = getRequiredFields(folder, version)

    if rfDict != {}:

        #walk through the tables/feature classes
        for dirpath, dirnames, filenames in Walk(gdb, True, '', False, ["Table","FeatureClass"]):
            for filename in filenames:
                fields = []
                fullPath = path.join(gdb, filename)

                #list fields
                fs = ListFields(fullPath)

                for f in fs:
                    fields.append(f.name.upper())

                #get the keyword to acquire required field names
                keyword = getKeyword(filename, esb)

                #get the appropriate comparison list
                if keyword in rfDict:
                    comparisonList = rfDict[keyword]
                    ## print comparisonList

                    #loop through required fields to make sure they exist in the geodatabase
                    for comparisonField in comparisonList:
                        if comparisonField.upper() not in fields:
                            report = filename + " does not have required field " + comparisonField
                            userMessage(report)
                            #add issue to list of values
                            val = (today, report, "Field")
                            values.append(val)

        #record issues if any exist
        if values != []:
            RecordResults("template", values, gdb)

        userMessage("Completed check for required fields: " + str(len(values)) + " issues found")

    else:
        userMessage("Could not check for required fields.")

def checkSubmissionNumbers(pathsInfoObject):
    #set variables
    gdb = pathsInfoObject.gdbPath
    esb = pathsInfoObject.esbList
    version = pathsInfoObject.gdbVersion
    gdbObject = getGDBObject(gdb)
    fcList = pathsInfoObject.fcList

##    #create list of feature classes & tables to check
##    fcList = [gdbObject.AddressPoints, gdbObject.RoadCenterline, gdbObject.RoadAlias, gdbObject.AuthoritativeBoundary, gdbObject.MunicipalBoundary]
##    for e in esb:
##        full_path = join(gdb, "NG911", e)
##        fcList.append(full_path)

    today = strftime("%m/%d/%y")
    values = []

    for fc in fcList:
        #count records that are for submission
        lyr2 = "lyr2"
        if version == "10":
            MakeTableView_management(fc, lyr2)
        else:
            wc2 = "SUBMIT = 'Y'"
            MakeTableView_management(fc, lyr2, wc2)

        #get count of the results
        result = GetCount_management(lyr2)
        count = int(result.getOutput(0))

        userMessage(basename(fc) + ": " + str(count) + " records marked for submission")

        if count == 0:
            report = basename(fc) + " has 0 records for submission"
            #add issue to list of values
            val = (today, report, "Submission")
            values.append(val)

        Delete_management(lyr2)

    #record issues if any exist
    if values != []:
        RecordResults("template", values, gdb)

def checkFeatureLocations(pathsInfoObject):
    gdb = pathsInfoObject.gdbPath
    fcList = pathsInfoObject.fcList
    esb = pathsInfoObject.esbList
    version = pathsInfoObject.gdbVersion

    RoadAlias = join(gdb, "RoadAlias")

    if RoadAlias in fcList:
        fcList.remove(RoadAlias)

    userMessage("Checking feature locations...")

    #get today's date
    today = strftime("%m/%d/%y")
    values = []

    #make sure features are all inside authoritative boundary

    #get authoritative boundary
    authBound = path.join(gdb, "NG911", "AuthoritativeBoundary")
    ab = "ab"

    MakeFeatureLayer_management(authBound, ab)

    for fullPath in fcList:
        fl = "fl"
        if version == "10":
            MakeFeatureLayer_management(fullPath, fl)
        else:
            if "RoadCenterline" in fullPath:
                wc = "SUBMIT = 'Y' AND EXCEPTION not in ('EXCEPTION INSIDE', 'EXCEPTION BOTH')"
            else:
                wc = "SUBMIT = 'Y'"
            MakeFeatureLayer_management(fullPath, fl, wc)

        try:

            #select by location to get count of features outside the authoritative boundary
            SelectLayerByLocation_management(fl, "WITHIN", ab)
            SelectLayerByAttribute_management(fl, "SWITCH_SELECTION", "")
            #get count of selected records
            result = GetCount_management(fl)
            count = int(result.getOutput(0))

            #report results
            if count > 0:
                layer = basename(fullPath)
                if layer in esb:
                    layerName = "ESB"
                else:
                    layerName = layer
                id1 = getUniqueIDField(layerName.upper())
                report = "Feature not inside authoritative boundary"
                if id1 != '':
                    with SearchCursor(fl, (id1)) as rows:
                        for row in rows:
                            fID = row[0]
                            val = (today, report, layer, " ", fID)
                            values.append(val)
                else:
                    userMessage("Could not process features in " + fullPath)
            else:
                userMessage( fullPath + ": all records inside authoritative boundary")
        except:
            userMessage("Could not check locations of " + fullPath)

        finally:

            #clean up
            Delete_management(fl)

    if values != []:
        RecordResults("fieldValues", values, gdb)


    userMessage("Completed check on feature locations: " + str(len(values)) + " issues found")

def sanityCheck(currentPathSettings):
    from Validation_ClearOldResults import ClearOldResults
    from NG911_Config import getGDBObject
    #fcList will contain all layers in GDB so everything will be checked

    #clear out template check results & field check results
    gdb = currentPathSettings.gdbPath
    ClearOldResults(gdb, "true", "true")

    gdbObject = getGDBObject(gdb)

    #check template
    checkLayerList(currentPathSettings)
    checkRequiredFields(currentPathSettings)
    checkRequiredFieldValues(currentPathSettings)
    checkSubmissionNumbers(currentPathSettings)

    #common layer checks
    checkValuesAgainstDomain(currentPathSettings)
    checkFeatureLocations(currentPathSettings)
    checkUniqueIDFrequency(currentPathSettings)

    #check address points
    geocodeAddressPoints(currentPathSettings)
    addressPoints = join(currentPathSettings.gdbPath, "AddressPoints")
    AP_freq = join(currentPathSettings.gdbPath, "AP_Freq")
    AP_fields = "MUNI;HNO;HNS;PRD;STP;RD;STS;POD;POM;ZIP;BLD;FLR;UNIT;ROOM;SEAT;LOC;LOCTYPE"
    checkFrequency(addressPoints, AP_freq, AP_fields, currentPathSettings.gdbPath, currentPathSettings.gdbVersion)
    if Exists(currentPathSettings.ESZ):
        checkESNandMuniAttribute(currentPathSettings)
    else:
        userMessage("ESZ layer does not exist. Cannot complete check.")

    #check roads
    roads = join(currentPathSettings.gdbPath, "RoadCenterline")
    road_freq = join(currentPathSettings.gdbPath, "Road_Freq")
    road_fields = """STATE_L;STATE_R;COUNTY_L;COUNTY_R;MUNI_L;MUNI_R;L_F_ADD;L_T_ADD;R_F_ADD;R_T_ADD;
    PARITY_L;PARITY_R;POSTCO_L;POSTCO_R;ZIP_L;ZIP_R;ESN_L;ESN_R;MSAGCO_L;MSAGCO_R;PRD;STP;RD;STS;POD;
    POM;SPDLIMIT;ONEWAY;RDCLASS;LABEL;ELEV_F;ELEV_T;ESN_C;SURFACE;STATUS;TRAVEL;LRSKEY"""
    checkFrequency(roads, road_freq, road_fields, currentPathSettings.gdbPath, currentPathSettings.gdbVersion)

    #verify that the check resulted in 0 issues
    sanity = 0 #flag to return at end
    numErrors = 0 #the total number of errors

    fieldCheckResults = gdbObject.FieldValuesCheckResults
    templateResults = gdbObject.TemplateCheckResults

    for table in [fieldCheckResults, templateResults]:
        if Exists(table):
            tbl = "tbl"
            MakeTableView_management(table, tbl)
            result = GetCount_management(tbl)
            count = int(result.getOutput(0))
            numErrors = numErrors + count
            Delete_management(tbl)

    #change result = 1
    if numErrors == 0:
        sanity = 1
        today = strftime("%m/%d/%y")
        values = [(today, "Passed all checks")]
        RecordResults("DASCmessage", values, gdb)
        userMessage("Geodatabase passed all data checks.")
    else:
        userMessage("There were " + str(numErrors) + " issues with the data. Please view errors in the TemplateCheckResults and:or FieldValuesCheckResults tables.")

    return sanity

def main_check(checkType, currentPathSettings):
##    try:
##        from NG911_Config import currentPathSettings # currentPathSettings should have all the path information available. ## import esb, gdb, folder
##    except:
##        userMessage( "Copy config file into command line")

    checkList = currentPathSettings.checkList

    #give user a warning if they didn't select any validation checks
    stuffToCheck = 0
    for cI in checkList:
        if cI == "true":
            stuffToCheck = stuffToCheck + 1
    if stuffToCheck == 0:
        userMessage("Warning: you choose no validation checks.")

    #check geodatabase template
    if checkType == "template":
        if checkList[0] == "true":
            checkLayerList(currentPathSettings)

        if checkList[1] == "true":
            checkRequiredFields(currentPathSettings)

        if checkList[2] == "true":
            checkRequiredFieldValues(currentPathSettings)

        if checkList[3] == "true":
            checkSubmissionNumbers(currentPathSettings)

    #check address points
    elif checkType == "AddressPoints":
        if checkList[0] == "true":
            checkValuesAgainstDomain(currentPathSettings)

        if checkList[1] == "true":
            checkFeatureLocations(currentPathSettings)

        if checkList[2] == "true":
            geocodeAddressPoints(currentPathSettings)

        if checkList[3] == "true":
            addressPoints = join(currentPathSettings.gdbPath, "AddressPoints")
            AP_freq = join(currentPathSettings.gdbPath, "AP_Freq")
            AP_fields = "MUNI;HNO;HNS;PRD;STP;RD;STS;POD;POM;ZIP;BLD;FLR;UNIT;ROOM;SEAT;LOC;LOCTYPE"
            checkFrequency(addressPoints, AP_freq, AP_fields, currentPathSettings.gdbPath, currentPathSettings.gdbVersion)

        if checkList[4] == "true":
            checkUniqueIDFrequency(currentPathSettings)

        if checkList[5] == "true":
            if Exists(currentPathSettings.ESZ):
                checkESNandMuniAttribute(currentPathSettings)
            else:
                userMessage("ESZ layer does not exist, cannot complete check.")

    #check roads
    elif checkType == "Roads":
        if checkList[0] == "true":
            checkValuesAgainstDomain(currentPathSettings)

        if checkList[1] == "true":
            checkFeatureLocations(currentPathSettings)

        if checkList[2] == "true":
            roads = join(currentPathSettings.gdbPath, "RoadCenterline")
            road_freq = join(currentPathSettings.gdbPath, "Road_Freq")
            road_fields = """STATE_L;STATE_R;COUNTY_L;COUNTY_R;MUNI_L;MUNI_R;L_F_ADD;L_T_ADD;R_F_ADD;R_T_ADD;
            PARITY_L;PARITY_R;POSTCO_L;POSTCO_R;ZIP_L;ZIP_R;ESN_L;ESN_R;MSAGCO_L;MSAGCO_R;PRD;STP;RD;STS;POD;
            POM;SPDLIMIT;ONEWAY;RDCLASS;LABEL;ELEV_F;ELEV_T;ESN_C;SURFACE;STATUS;TRAVEL;LRSKEY"""
            checkFrequency(roads, road_freq, road_fields, currentPathSettings.gdbPath, currentPathSettings.gdbVersion)

        if checkList[3] == "true":
            checkUniqueIDFrequency(currentPathSettings)

    #check boundaries or ESB
    elif checkType in ("admin", "ESB"):
        if checkList[0] == "true":
            checkValuesAgainstDomain(currentPathSettings)

        if checkList[1] == "true":
            checkFeatureLocations(currentPathSettings)

        if checkList[2] == "true":
            checkUniqueIDFrequency(currentPathSettings)


if __name__ == '__main__':
    main()
